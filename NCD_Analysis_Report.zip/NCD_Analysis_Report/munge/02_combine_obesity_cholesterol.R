# Munge/02_combine_obesity_cholesterol.R
# This script combines the obesity trend data with cholesterol data.

library(data.table)
library(tidyverse)

# Load the required datasets (obesity from Cache, cholesterol raw from Data)
df_obesity <- fread("Cache/obesity_trend_data.csv") 
df_cholesterol_raw <- fread("Data/NCD_RisC_Nature_2020_Cholesterol_age_standardised_countries.csv")

# Clean and select cholesterol data
df_cholesterol <- df_cholesterol_raw %>%
  select(
    Year,
    Country = `Country/Region/World`,
    Sex,
    Mean_Cholesterol = `Mean total cholesterol (mmol/L)`
  ) %>%
  filter(Country %in% c("United States of America", "India"), Year >= 1990)

# Join the two datasets by Country, Sex, and Year using inner_join
df_combined_data <- inner_join(
  df_obesity,
  df_cholesterol,
  by = c("Year", "Country", "Sex")
)

# Save the combined data to the Cache folder
fwrite(df_combined_data, "Cache/combined_obesity_cholesterol.csv")

cat("Combined obesity and cholesterol data prepared and saved to Cache/combined_obesity_cholesterol.csv\n")