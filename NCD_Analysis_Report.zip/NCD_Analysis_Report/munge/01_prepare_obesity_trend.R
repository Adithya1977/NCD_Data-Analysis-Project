# Munge/01_prepare_obesity_trend.R
# This script reads the raw BMI data and saves the filtered data to the Cache folder.

library(data.table)
library(tidyverse)

# Load the raw adult BMI data (Path is correct for running from the main directory)
df_bmi_adult <- fread("Data/NCD_RisC_Lancet_2024_BMI_age_standardised_country.csv")

# Select key columns and filter for the specified countries
df_obesity_trend <- df_bmi_adult %>%
  select(
    Year,
    Country = `Country/Region/World`,
    Sex,
    Prevalence = `Prevalence of BMI>=30 kg/m² (obesity)`
  ) %>%
  filter(Country %in% c("United States of America", "India"), Year >= 1990)

# Save the prepared data to the Cache folder
fwrite(df_obesity_trend, "Cache/obesity_trend_data.csv")

cat("Obesity trend data prepared and saved to Cache/obesity_trend_data.csv\n")