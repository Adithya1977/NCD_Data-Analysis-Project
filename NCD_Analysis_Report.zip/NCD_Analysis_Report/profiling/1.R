# Example Profiling Script

replicate(10, system.time(rnorm(100000, 0, 1)))
